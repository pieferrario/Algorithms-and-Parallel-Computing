//
// Created by pietr on 23/10/2026.
//

#ifndef EMPLOYEE_SECRETARY_H
#define EMPLOYEE_SECRETARY_H

#include "Employee.h"

class Secretary: public Employee
{
public:
    Secretary(const std::string & ,
    const std::string & ,
    const unsigned & );
    void print() const;
};


#endif //EMPLOYEE_SECRETARY_H
